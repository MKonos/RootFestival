#!/sbin/sh

# CORTEX
if [ "$1" = "CORTEX_ENABLED" ]; then
	echo "cortex_enabled" >> /system/SkyHigh.prop
fi;

# CRONTAB
if [ "$1" = "CRONTAB_ENABLED" ]; then
	echo "crontab_enabled" >> /system/SkyHigh.prop
fi;

