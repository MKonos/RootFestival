#!/sbin/sh

if [ ! -f /data/misc/media_profiles.bak ]; then
  cp -a /system/etc/media_profiles.xml /data/misc/media_profiles.bak
fi

if [ ! -f /data/misc/camera-feature-v7.bak ]; then
  cp -a /system/cameradata/camera-feature-v7.xml /data/misc/camera-feature-v7.bak
fi

if [ ! -f /data/misc/SamsungCamera7.bak ]; then
  cp -a /system/priv-app/SamsungCamera7/SamsungCamera7.apk /data/misc/SamsungCamera7.bak
fi

mv /system/priv-app/SamsungCamera7/oat /system/priv-app/SamsungCamera7/oatbak

getprop ro.boot.bootloader >> /tmp/BLmodel

cp -a /tmp/media_profiles.xml /system/etc/media_profiles.xml

if [ -f /system/lib/libexynoscamera.so ]; then
	
	if grep -q N95 /tmp/BLmodel; then
	  cp -a /tmp/camera-feature-v7_N8_exynos.xml /system/cameradata/camera-feature-v7.xml
	else if grep -q G95 /tmp/BLmodel; then
		cp -a /tmp/camera-feature-v7_S8_exynos.xml /system/cameradata/camera-feature-v7.xml
	else if grep -q G93 /tmp/BLmodel; then	
		cp -a /tmp/camera-feature-v7_S7_exynos.xml /system/cameradata/camera-feature-v7.xml		
	fi
	fi
	fi
	cp -a /tmp/SamsungCamera7_exynos.apk /system/priv-app/SamsungCamera7/SamsungCamera7.apk
else

	if grep -q N95 /tmp/BLmodel; then
	  cp -a /tmp/camera-feature-v7_N8_snapdragon.xml /system/cameradata/camera-feature-v7.xml
	else if grep -q G95 /tmp/BLmodel; then
		cp -a /tmp/camera-feature-v7_S8_snapdragon.xml /system/cameradata/camera-feature-v7.xml
	else if grep -q G93 /tmp/BLmodel; then	
		cp -a /tmp/camera-feature-v7_S7_snapdragon.xml /system/cameradata/camera-feature-v7.xml		
	fi
	fi
	fi
	cp -a /tmp/SamsungCamera7_snapdragon.apk /system/priv-app/SamsungCamera7/SamsungCamera7.apk
fi

if [ -f /data/dalvik-cache/arm64/system@priv-app@SamsungCamera7@SamsungCamera7.apk@classes.dex ]; then
  rm /data/dalvik-cache/arm64/system@priv-app@SamsungCamera7@SamsungCamera7.apk@classes.dex
fi

if [ -f /data/dalvik-cache/arm64/system@priv-app@SamsungCamera7@SamsungCamera7.apk@classes.art ]; then
  rm /data/dalvik-cache/arm64/system@priv-app@SamsungCamera7@SamsungCamera7.apk@classes.art
fi

rm /data/data/com.sec.android.app.camera
