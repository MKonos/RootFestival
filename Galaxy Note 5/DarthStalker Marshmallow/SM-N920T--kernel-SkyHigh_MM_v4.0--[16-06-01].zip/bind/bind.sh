#!/sbin/sh

if [ -f /data/.supersu ]; then
	rm -rf /data/.supersu;
	echo BINDSYSTEMXBIN=true >> /data/.supersu;
	sync;
fi;
