#!/system/bin/sh
cp -a /system/etc/media_profiles.bak /system/etc/media_profiles.xml
cp -a /system/cameradata/camera-feature-v7.bak /system/cameradata/camera-feature-v7.xml
cp -a /system/priv-app/SamsungCamera7/SamsungCamera7.bak /system/priv-app/SamsungCamera7/SamsungCamera7.apk
mv /system/priv-app/SamsungCamera7/oatbak /system/priv-app/SamsungCamera7/oat
rm /data/dalvik-cache/arm64/system@priv-app@SamsungCamera7@SamsungCamera7.apk@classes.dex
rm /data/dalvik-cache/arm64/system@priv-app@SamsungCamera7@SamsungCamera7.apk@classes.art
rm /data/data/com.sec.android.app.camera
cp -a /data/misc/media_profiles.bak /system/etc/media_profiles.xml
cp -a /data/misc/camera-feature-v7.bak /system/cameradata/camera-feature-v7.xml
cp -a /data/misc/SamsungCamera7.bak /system/priv-app/SamsungCamera7/SamsungCamera7.apk
cp -a /data/misc/libstagefright.bak /system/lib/libstagefright.so