am start -a android.intent.action.MAIN -n <FACTIVITY>
sleep 1
killall <ACTIVITY>
killall audioserver
killall mediaserver