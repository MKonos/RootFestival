Information:
UPPERCUT adds instant and automatic support for your LG device in LGUP. What's LGUP? LGUP is LG's internal Windows tool for flashing LG devices with stock firmware in KDZ, DZ and TOT formats. Previously extra installers for specific models or fiddling around in the registry was needed. Well with UPPERCUT just double-click the EXE and LGUP will open and recognize your device. 

Requirements:
1. Windows computer or virtual machine.
2. LG's Windows USB drivers installed and working.
3. LGUP 1.14 installed
4. LG device must show in Windows Device Manager under "Ports" as a LG Serial COM port.
5. KDZ, DZ or TOT file for your device. 

How-to:
1. With all requirements above met... download and unzip UPPERCUT.
2. Double-click the UPPERCUT.exe every time you want to use LGUP. It's that simple.

Versions:
1.0.0.0 - Supports LG devices using a MSM 8996/8994/8992/8976/8939/8916/8226 chipset. Street Fighter 2 SFX.


Official Support Thread: http://bit.ly/LGUPPERCUT
This file was originally hosted on Codefire.